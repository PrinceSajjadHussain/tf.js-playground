<template>
  <div>
    <div class="container vh-100 pt-3">
      <h1>A Sample Use Case Demo</h1>
      <p>
        In this demo, we will be exploring the Speech Command Recognizer
        model.
      </p>

      <div class="embed-responsive embed-responsive-16by9">
        <iframe loading="lazy"
          title="Demo"
          src="https:&#x2F;&#x2F;www.canva.com&#x2F;design&#x2F;DAE5tOdiXV8&#x2F;watch?embed"
          allowfullscreen="allowfullscreen" allow="fullscreen">
          </iframe>
      </div>
    </div>

    <the-footer></the-footer>
  </div>
</template>

<script>
import TheFooter from '../components/TheFooter.vue';

export default {
  name: 'DemoPage',
  components: {
    TheFooter,
  },
};
</script>

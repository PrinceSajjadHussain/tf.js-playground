import html from './html';
import css from './css';
import javascript from './javascript';

export default {
  html,
  css,
  javascript,
};

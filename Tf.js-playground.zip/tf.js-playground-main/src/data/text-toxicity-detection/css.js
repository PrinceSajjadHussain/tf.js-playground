export default [
  '@import url("https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css");',
  '@import url("https://res.cloudinary.com/missada/raw/upload/v1645344242/Tf.js%20Playground/playground-general-styles.css");',
  '',
  '.sub-heading {',
  '  display: block;',
  '  font-size: 0.7em;',
  '  margin-left: 35px;',
  '  margin-top: -5px;',
  '}',
  '',
].join('\n');

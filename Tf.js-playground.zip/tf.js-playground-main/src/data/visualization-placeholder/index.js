import html from './html';
import css from './css';

export default {
  html,
  css,
};
